import { db } from './firebase';
import { collection, doc, getDoc, getDocs, setDoc, updateDoc, deleteDoc, query, onSnapshot, orderBy } from 'firebase/firestore';

export const getFirebaseData = async (collectionName: string) => {
  const q = query(collection(db, collectionName));
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => ({ ...doc.data(), id: doc.id }));
};

export const setFirebaseData = async (collectionName: string, id: string, data: any) => {
  await setDoc(doc(db, collectionName, id.toString()), data);
};

export const deleteFirebaseData = async (collectionName: string, id: string) => {
  await deleteDoc(doc(db, collectionName, id.toString()));
};

export const subscribeToCollection = (collectionName: string, callback: (data: any[]) => void) => {
  const q = query(collection(db, collectionName));
  return onSnapshot(q, (querySnapshot) => {
    callback(querySnapshot.docs.map(doc => ({ ...doc.data(), id: doc.id })));
  });
};

export const getFirebaseDoc = async (collectionName: string, id: string) => {
  const docRef = doc(db, collectionName, id);
  const docSnap = await getDoc(docRef);
  if (docSnap.exists()) {
    return { ...docSnap.data(), id: docSnap.id };
  }
  return null;
};
