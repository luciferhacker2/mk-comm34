/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Categories from './components/Categories';
import Products from './components/Products';
import Founder from './components/Founder';
import Features from './components/Features';
import Testimonials from './components/Testimonials';
import Gallery from './components/Gallery';
import Footer from './components/Footer';
import CartDrawer from './components/CartDrawer';
import AdminPanel from './components/AdminPanel';
import { CartProvider } from './context/CartContext';
import { AuthProvider } from './context/AuthContext';
import { useState, useEffect } from 'react';

export default function App() {
  const [isAdminOpen, setIsAdminOpen] = useState(false);

  useEffect(() => {
    // Increment visits
    try {
      const v = localStorage.getItem('mk_visits');
      const count = v ? parseInt(v) : 0;
      localStorage.setItem('mk_visits', (count + 1).toString());
    } catch(e) {}
    
    // Listen for custom event to open admin
    const handleOpenAdmin = () => setIsAdminOpen(true);
    window.addEventListener('open-admin', handleOpenAdmin);
    return () => window.removeEventListener('open-admin', handleOpenAdmin);
  }, []);

  return (
    <AuthProvider>
      <CartProvider>
        <div className="relative w-full bg-luxury-black min-h-screen text-white">
          <Navbar />
          <Hero />
          <Features />
          <Categories />
          <Products />
          <Founder />
          <Testimonials />
          <Gallery />
          <Footer />
          <CartDrawer />
          {isAdminOpen && <AdminPanel onClose={() => setIsAdminOpen(false)} />}
        </div>
      </CartProvider>
    </AuthProvider>
  );
}

