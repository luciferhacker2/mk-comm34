import { motion } from 'motion/react';
import { Facebook, Twitter, Instagram, Youtube, MapPin, Phone, Mail } from 'lucide-react';
import { useState } from 'react';
import PolicyModal from './PolicyModal';

export default function Footer() {
  const [activePolicy, setActivePolicy] = useState<'faq' | 'shipping' | 'returns' | 'privacy' | 'terms' | null>(null);

  const policyLinks = [
    { label: 'FAQ', type: 'faq' },
    { label: 'Shipping Policy', type: 'shipping' },
    { label: 'Returns & Refunds', type: 'returns' },
    { label: 'Privacy Policy', type: 'privacy' },
    { label: 'Terms of Service', type: 'terms' }
  ] as const;

  return (
    <>
    <footer id="contact" className="bg-luxury-black text-white pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8 mb-16">
          
          {/* Brand Info */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div className="text-xl md:text-2xl font-display font-bold tracking-tighter uppercase flex items-center gap-1.5 mb-6 text-white">
              <span className="w-6 h-6 bg-white text-black flex items-center justify-center rounded-sm text-sm">M</span>
              <span className="w-6 h-6 bg-white text-black flex items-center justify-center rounded-sm text-sm">K</span>
              <span className="ml-1 tracking-widest font-medium text-base">COMMUNICATION</span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed mb-6">
              Elevating your tech lifestyle with premium minimalist mobile accessories and gadgets designed for the modern world.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-white hover:text-black transition-all">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-white hover:text-black transition-all">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="https://www.instagram.com/mk_communicaation999?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-white hover:text-black transition-all">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="https://youtube.com/@mkcommunication1?si=5jy3IUtqJgzBhgqT" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-white hover:text-black transition-all">
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <h4 className="font-semibold text-lg mb-6 tracking-wide">Explore</h4>
            <ul className="space-y-4">
              {['Home', 'Products', 'Categories', 'About Us', 'Contact'].map((link) => (
                <li key={link}>
                  <a href={`#${link.toLowerCase().replace(' ', '-')}`} className="text-gray-400 hover:text-white transition-colors text-sm">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Customer Care */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h4 className="font-semibold text-lg mb-6 tracking-wide">Customer Care</h4>
            <ul className="space-y-4">
              {policyLinks.map((link) => (
                <li key={link.type}>
                  <button onClick={() => setActivePolicy(link.type)} className="text-gray-400 hover:text-white transition-colors text-sm text-left">
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Contact Details */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <h4 className="font-semibold text-lg mb-6 tracking-wide">Contact Us</h4>
            <ul className="space-y-5">
              <li className="flex items-start gap-4 text-gray-400 hover:text-white transition-colors">
                <MapPin className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <span className="text-sm">7th Floor, Innovation Tower, Tech District, City Center</span>
              </li>
              <li className="flex items-center gap-4 text-gray-400 hover:text-white transition-colors">
                <Phone className="w-5 h-5 flex-shrink-0" />
                <span className="text-sm">+1 (800) 123-4567</span>
              </li>
              <li className="flex items-center gap-4 text-gray-400 hover:text-white transition-colors">
                <Mail className="w-5 h-5 flex-shrink-0" />
                <span className="text-sm">hello@mkcommunication.com</span>
              </li>
            </ul>
          </motion.div>

        </div>

        <div className="border-t border-white/10 pt-8 mt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-500">
          <p 
            onDoubleClick={() => window.dispatchEvent(new Event('open-admin'))}
            className="cursor-default select-none"
          >
            &copy; {new Date().getFullYear()} MK Communication. All rights reserved.
          </p>
          <div className="flex gap-4">
            <span>Designed for Excellence</span>
          </div>
        </div>
      </div>
    </footer>
    
    <PolicyModal 
      isOpen={!!activePolicy} 
      policyType={activePolicy} 
      onClose={() => setActivePolicy(null)} 
    />
    </>
  );
}
