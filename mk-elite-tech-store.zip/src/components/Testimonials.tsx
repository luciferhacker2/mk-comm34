import { motion, AnimatePresence } from 'motion/react';
import { Star, Plus, X } from 'lucide-react';
import { useState, useEffect } from 'react';
import { TESTIMONIALS } from '../data';
import { useAuth } from '../context/AuthContext';

interface Testimonial {
  id: number;
  name: string;
  role: string;
  content: string;
  image: string;
  rating: number;
}

export default function Testimonials() {
  const { user } = useAuth();
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newReview, setNewReview] = useState({ rating: 5, content: '', role: 'Verified Buyer' });

  useEffect(() => {
    const loadTestimonials = () => {
      const saved = localStorage.getItem('mk_testimonials');
      if (saved) {
        try {
          setTestimonials(JSON.parse(saved));
        } catch (e) {
          setTestimonials(TESTIMONIALS);
        }
      } else {
        setTestimonials(TESTIMONIALS);
      }
    };

    loadTestimonials();
    window.addEventListener('testimonials-updated', loadTestimonials);
    return () => window.removeEventListener('testimonials-updated', loadTestimonials);
  }, []);

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReview.content.trim()) return;

    const newTestimonial: Testimonial = {
      id: Date.now(),
      name: user?.displayName || 'Anonymous User',
      role: newReview.role,
      content: newReview.content,
      image: user?.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.displayName || 'Anonymous')}&background=random`,
      rating: newReview.rating
    };

    const updatedTestimonials = [newTestimonial, ...testimonials];
    setTestimonials(updatedTestimonials);
    localStorage.setItem('mk_testimonials', JSON.stringify(updatedTestimonials));
    
    setNewReview({ rating: 5, content: '', role: 'Verified Buyer' });
    setIsModalOpen(false);
  };

  return (
    <section className="py-24 bg-luxury-zinc text-white overflow-hidden relative">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16 flex flex-col items-center">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-display font-bold mb-4"
          >
            Client Perspectives
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-gray-400 max-w-xl mx-auto mb-8"
          >
            What our community says about their MK Communication experience.
          </motion.p>
          
          <motion.button
            onClick={() => setIsModalOpen(true)}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-white text-black font-semibold rounded-full px-6 py-3 flex items-center gap-2 hover:bg-gray-200 transition-colors"
          >
            <Plus className="w-4 h-4" /> Leave a Review
          </motion.button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-luxury-black p-8 rounded-2xl border border-white/5 relative group hover:border-white/20 transition-colors flex flex-col"
            >
              <div className="flex gap-1 text-yellow-500 mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className={`w-4 h-4 ${i < testimonial.rating ? 'fill-current' : 'text-gray-700'}`} 
                  />
                ))}
              </div>
              <p className="text-gray-300 font-light leading-relaxed mb-8 italic flex-grow">
                "{testimonial.content}"
              </p>
              <div className="flex items-center gap-4 mt-auto">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name} 
                  className="w-12 h-12 rounded-full object-cover filter grayscale group-hover:grayscale-0 transition-all duration-500"
                />
                <div>
                  <h4 className="font-semibold text-sm">{testimonial.name}</h4>
                  <p className="text-xs text-gray-500">{testimonial.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-lg bg-luxury-zinc border border-white/10 rounded-2xl p-8 shadow-2xl overflow-hidden"
            >
              <button 
                onClick={() => setIsModalOpen(false)}
                className="absolute top-4 right-4 p-2 text-gray-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              
              <div className="mb-6">
                <h3 className="text-2xl font-display font-medium text-white mb-2">Share Your Experience</h3>
                <p className="text-gray-400 text-sm">We'd love to hear about your experience with MK Communication.</p>
                {!user && (
                   <p className="text-xs text-yellow-500 mt-2">You will be posting as an Anonymous User because you are not logged in.</p>
                )}
              </div>

              <form onSubmit={handleReviewSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Your Rating</label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setNewReview({ ...newReview, rating: star })}
                        className="focus:outline-none transition-transform hover:scale-110"
                      >
                        <Star 
                          className={`w-8 h-8 ${star <= newReview.rating ? 'fill-yellow-500 text-yellow-500' : 'text-gray-600'}`} 
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Your Review</label>
                  <textarea 
                    required
                    value={newReview.content}
                    onChange={(e) => setNewReview({ ...newReview, content: e.target.value })}
                    placeholder="Tell us what you loved..." 
                    rows={4}
                    className="w-full bg-luxury-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30 transition-colors resize-none"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
                  <button 
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-5 py-2.5 text-sm font-medium text-gray-300 hover:text-white transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    disabled={!newReview.content.trim()}
                    className="bg-white text-black text-sm font-semibold rounded-lg px-6 py-2.5 hover:bg-gray-200 transition-colors disabled:opacity-50"
                  >
                    Post Review
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
