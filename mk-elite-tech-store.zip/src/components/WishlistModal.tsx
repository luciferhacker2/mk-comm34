import { motion, AnimatePresence } from 'motion/react';
import { X, Heart, ShoppingBag, Trash2 } from 'lucide-react';
import { useCart } from '../context/CartContext';

interface WishlistModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function WishlistModal({ isOpen, onClose }: WishlistModalProps) {
  const { wishlistItems, toggleWishlist, addToCart } = useCart();

  const handleMoveToCart = (item: { id: number, name: string, price: number, image: string }) => {
    addToCart(item);
    toggleWishlist(item); // Remove from wishlist
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-2xl bg-luxury-zinc border border-white/10 rounded-2xl p-6 md:p-8 shadow-2xl flex flex-col max-h-[90vh]"
          >
            <button 
              onClick={onClose}
              className="absolute top-4 right-4 p-2 text-gray-400 hover:text-white transition-colors bg-black/20 rounded-full z-10"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="flex items-center gap-3 mb-6 pb-4 border-b border-white/10">
              <Heart className="w-6 h-6 text-white" />
              <h2 className="text-2xl font-display font-medium text-white">Your Wishlist</h2>
            </div>
            
            <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar">
              {wishlistItems.length === 0 ? (
                <div className="text-center py-12 flex flex-col items-center">
                  <Heart className="w-16 h-16 text-white/20 mb-4" />
                  <p className="text-gray-400">Your wishlist is empty.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {wishlistItems.map((item) => (
                    <div key={item.id} className="bg-black/50 border border-white/10 rounded-xl p-4 hover:border-white/30 transition-colors flex items-center gap-4">
                      <div className="w-20 h-20 rounded-lg bg-white/5 overflow-hidden flex-shrink-0">
                        <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="text-white font-medium truncate">{item.name}</h3>
                        <p className="text-gray-400 mt-1">₹{item.price.toLocaleString('en-IN')}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleMoveToCart(item)}
                          className="p-2 bg-white text-black hover:bg-gray-200 rounded-full transition-colors"
                          title="Move to Cart"
                        >
                          <ShoppingBag className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => toggleWishlist(item)}
                          className="p-2 bg-red-500/10 text-red-500 hover:bg-red-500/20 rounded-full transition-colors"
                          title="Remove from Wishlist"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
