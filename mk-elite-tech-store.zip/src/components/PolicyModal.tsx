import { motion, AnimatePresence } from 'motion/react';
import { X, ShieldCheck, Truck, ArrowLeftRight, FileText, Info } from 'lucide-react';

interface PolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
  policyType: 'faq' | 'shipping' | 'returns' | 'privacy' | 'terms' | null;
}

export default function PolicyModal({ isOpen, onClose, policyType }: PolicyModalProps) {
  if (!policyType) return null;

  const POLICIES = {
    faq: {
      title: 'Frequently Asked Questions',
      icon: <Info className="w-6 h-6" />,
      content: [
        { q: 'How long does shipping take?', a: 'Standard shipping takes 3-5 business days. Express shipping takes 1-2 business days.' },
        { q: 'Do you ship internationally?', a: 'Yes, we ship to most countries worldwide. International shipping usually takes 7-14 days.' },
        { q: 'Can I change my order after placing it?', a: 'You can change or cancel your order within 2 hours of placing it. Please contact support immediately.' },
        { q: 'Are your products authentic?', a: 'Yes, all our products are 100% authentic and come with standard manufacturer warranties.' },
      ]
    },
    shipping: {
      title: 'Shipping Policy',
      icon: <Truck className="w-6 h-6" />,
      content: 'We aim to process all orders within 24 hours of receipt. Weekend orders will be dispatched on the following Monday. You will receive a tracking link via email or SMS once your package leaves our fulfillment center. Domestic shipping is free on orders above ₹1,500. For orders below this amount, a standard fee of ₹100 applies. In case of delays, please contact our support team.'
    },
    returns: {
      title: 'Returns & Refunds',
      icon: <ArrowLeftRight className="w-6 h-6" />,
      content: 'We offer a 7-day hassle-free return window for all unused items in their original packaging. If you receive a defective product, please notify us within 48 hours for a free replacement. Refunds are initiated once the returned item passes our quality check. The refund amount should reflect in your original payment method within 5-7 business days.'
    },
    privacy: {
      title: 'Privacy Policy',
      icon: <ShieldCheck className="w-6 h-6" />,
      content: 'Your privacy is important to us. MK Communication collects personal information only to process your orders, improve your shopping experience, and communicate with you. We do not sell or share your data with third parties without your consent. Our payment gateways use industry-standard encryption to keep your financial information completely secure.'
    },
    terms: {
      title: 'Terms of Service',
      icon: <FileText className="w-6 h-6" />,
      content: 'By using this website, you agree to our Terms of Service. Prices and availability of products are subject to change without notice. We reserve the right to refuse service, terminate accounts, or cancel orders at our discretion. All content, images, and text on this site are the intellectual property of MK Communication and cannot be reproduced without permission.'
    }
  };

  const data = POLICIES[policyType];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-2xl bg-luxury-zinc border border-white/10 rounded-2xl p-6 md:p-8 shadow-2xl flex flex-col max-h-[85vh] overflow-y-auto custom-scrollbar"
          >
            <button 
              onClick={onClose}
              className="absolute top-4 right-4 p-2 text-gray-400 hover:text-white transition-colors bg-black/20 rounded-full z-10"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="flex items-center gap-3 mb-8 border-b border-white/5 pb-4">
              <div className="text-white bg-white/10 p-3 rounded-xl">{data.icon}</div>
              <h2 className="text-2xl font-display font-medium text-white">{data.title}</h2>
            </div>
            
            <div className="text-gray-300 leading-relaxed text-sm md:text-base space-y-6">
              {Array.isArray(data.content) ? (
                <div className="space-y-6">
                  {data.content.map((faq, i) => (
                    <div key={i} className="bg-black/30 p-5 rounded-xl border border-white/5 text-left">
                      <h3 className="text-white font-medium mb-2 text-base">{faq.q}</h3>
                      <p className="text-gray-400 text-sm">{faq.a}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="whitespace-pre-line bg-black/30 p-6 rounded-xl border border-white/5">{data.content}</p>
              )}
            </div>
            
            <div className="mt-8 pt-6 border-t border-white/5 text-center">
              <p className="text-xs text-gray-500 uppercase tracking-widest">MK Communication Support</p>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
