import { motion, AnimatePresence } from 'motion/react';
import { X, Search, Package, CheckCircle2, Truck, MapPin } from 'lucide-react';
import { useState } from 'react';

interface OrderTrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function OrderTrackingModal({ isOpen, onClose }: OrderTrackingModalProps) {
  const [phone, setPhone] = useState('');
  const [orderId, setOrderId] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [orderStatus, setOrderStatus] = useState<null | 'pending' | 'processing' | 'shipped' | 'delivered' | 'confirmed' | 'cancelled' | 'return_requested' | 'returned' | 'not_found'>(null);
  const [showReturnForm, setShowReturnForm] = useState(false);
  const [returnReason, setReturnReason] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone || !orderId) return;
    
    setIsSearching(true);
    setOrderStatus(null);
    setShowReturnForm(false);
    setReturnReason('');
    
    setTimeout(() => {
      setIsSearching(false);
      try {
        const o = localStorage.getItem('mk_orders');
        const orders = o ? JSON.parse(o) : [];
        const found = orders.find((x: any) => x.id === orderId && x.customerPhone === phone);
        if (found) {
          setOrderStatus(found.status || 'pending');
        } else {
          setOrderStatus('not_found');
        }
      } catch(e) {
        setOrderStatus('not_found');
      }
    }, 1000);
  };

  const handleCancelOrder = () => {
    try {
      const o = localStorage.getItem('mk_orders');
      let orders = o ? JSON.parse(o) : [];
      let canCancel = true;
      
      orders = orders.map((order: any) => {
        if (order.id === orderId && order.customerPhone === phone) {
          if (order.status === 'shipped' || order.status === 'delivered') {
            canCancel = false;
            return order;
          }
          return { ...order, status: 'cancelled' };
        }
        return order;
      });

      if (!canCancel) {
        return;
      }

      localStorage.setItem('mk_orders', JSON.stringify(orders));
      setOrderStatus('cancelled');
    } catch(e) {}
  };

  const handleReturnRequest = () => {
    if (!returnReason.trim()) return;
    try {
      const o = localStorage.getItem('mk_orders');
      let orders = o ? JSON.parse(o) : [];
      let updated = false;

      orders = orders.map((order: any) => {
        if (order.id === orderId && order.customerPhone === phone && order.status === 'delivered') {
          updated = true;
          return { ...order, status: 'return_requested', returnReason: returnReason.trim() };
        }
        return order;
      });

      if (updated) {
        localStorage.setItem('mk_orders', JSON.stringify(orders));
        setOrderStatus('return_requested');
        setShowReturnForm(false);
      }
    } catch (e) {}
  };

  const closeAndReset = () => {
    onClose();
    setTimeout(() => {
      setPhone('');
      setOrderId('');
      setOrderStatus(null);
      setShowReturnForm(false);
      setReturnReason('');
    }, 300);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeAndReset}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-md bg-luxury-zinc border border-white/10 rounded-2xl p-8 shadow-2xl overflow-hidden"
          >
            <button 
              onClick={closeAndReset}
              className="absolute top-4 right-4 p-2 text-gray-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="text-center mb-6">
              <Package className="w-12 h-12 text-white/50 mx-auto mb-4" />
              <h3 className="text-2xl font-display font-medium text-white mb-2">Track Your Order</h3>
              <p className="text-gray-400 text-sm">Enter your phone number and order ID to check status.</p>
            </div>

            <form onSubmit={handleSearch} className="space-y-4 mb-6">
              <div>
                <input 
                  type="tel" 
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                  placeholder="Phone Number" 
                  className="w-full bg-luxury-black border border-white/10 rounded-t-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30 transition-colors"
                />
                <input 
                  type="text" 
                  value={orderId}
                  onChange={(e) => setOrderId(e.target.value)}
                  required
                  placeholder="Order ID (e.g. MK123456)" 
                  className="w-full bg-luxury-black border-x border-b border-white/10 rounded-b-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30 transition-colors"
                />
              </div>
              <button 
                type="submit"
                disabled={isSearching}
                className="w-full bg-white text-black font-semibold rounded-lg py-3 flex items-center justify-center gap-2 hover:bg-gray-200 transition-colors disabled:opacity-70"
              >
                {isSearching ? (
                  <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <>
                    <Search className="w-4 h-4" /> Track Order
                  </>
                )}
              </button>
            </form>

            <AnimatePresence mode="wait">
              {orderStatus && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="border-t border-white/10 pt-6"
                >
                  {orderStatus === 'not_found' ? (
                    <div className="text-center py-4 text-red-400 text-sm">
                      We couldn't find an order with that ID and phone number. Please check your details and try again.
                    </div>
                  ) : (
                    <div className="space-y-6">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400">Order Status:</span>
                        <span className="font-medium text-white capitalize">{orderStatus}</span>
                      </div>
                      
                      <div className="relative">
                        {/* Timeline wire */}
                        <div className="absolute left-4 top-0 bottom-0 w-px bg-white/10"></div>
                        
                        {/* Steps */}
                        <div className="space-y-6">
                          {orderStatus === 'cancelled' ? (
                            <div className="relative flex items-center gap-4">
                              <div className="w-8 h-8 rounded-full flex items-center justify-center z-10 bg-red-500 text-white">
                                <X className="w-4 h-4" />
                              </div>
                              <div>
                                <p className="font-medium text-red-500">Order Cancelled</p>
                                <p className="text-xs text-gray-500">This order has been cancelled.</p>
                              </div>
                            </div>
                          ) : (
                            <>
                              {/* Processing */}
                              <div className="relative flex items-center gap-4">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center z-10 ${
                                  orderStatus === 'pending' || orderStatus === 'confirmed' || orderStatus === 'processing' || orderStatus === 'shipped' || orderStatus === 'delivered'
                                    ? 'bg-white text-black' 
                                    : 'bg-luxury-black border border-white/20 text-gray-500'
                                }`}>
                                  <Package className="w-4 h-4" />
                                </div>
                                <div>
                                  <p className={`font-medium ${orderStatus === 'pending' || orderStatus === 'confirmed' || orderStatus === 'processing' || orderStatus === 'shipped' || orderStatus === 'delivered' ? 'text-white' : 'text-gray-500'}`}>Order Processed</p>
                                  <p className="text-xs text-gray-500">We have received your order.</p>
                                </div>
                              </div>
                              
                              {/* Confirmed/Shipped */}
                              <div className="relative flex items-center gap-4">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center z-10 ${
                                  orderStatus === 'shipped' || orderStatus === 'delivered' || orderStatus === 'confirmed'
                                    ? 'bg-white text-black' 
                                    : 'bg-luxury-black border border-white/20 text-gray-500'
                                }`}>
                                  <Truck className="w-4 h-4" />
                                </div>
                                <div>
                                  <p className={`font-medium ${orderStatus === 'shipped' || orderStatus === 'delivered' || orderStatus === 'confirmed' ? 'text-white' : 'text-gray-500'}`}>Confirmed & Tracking</p>
                                  <p className="text-xs text-gray-500">Your order is confirmed and on the way.</p>
                                </div>
                              </div>
                              
                              {/* Delivered */}
                              <div className="relative flex items-center gap-4">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center z-10 ${
                                  orderStatus === 'delivered'
                                    ? 'bg-green-500 text-black' 
                                    : 'bg-luxury-black border border-white/20 text-gray-500'
                                }`}>
                                  <CheckCircle2 className="w-4 h-4" />
                                </div>
                                <div>
                                  <p className={`font-medium ${orderStatus === 'delivered' ? 'text-white' : 'text-gray-500'}`}>Delivered</p>
                                  <p className="text-xs text-gray-500">Package has arrived.</p>
                                </div>
                              </div>
                            </>
                          )}
                        </div>
                      </div>

                      {(orderStatus === 'pending' || orderStatus === 'confirmed') && (
                        <div className="pt-4 border-t border-white/10 text-center">
                          <button 
                            onClick={handleCancelOrder}
                            className="text-sm text-red-500 hover:text-red-400 font-medium underline underline-offset-4"
                          >
                            Cancel This Order
                          </button>
                        </div>
                      )}

                      {orderStatus === 'delivered' && !showReturnForm && (
                        <div className="pt-4 border-t border-white/10 text-center">
                          <button 
                            onClick={() => setShowReturnForm(true)}
                            className="text-sm text-yellow-500 hover:text-yellow-400 font-medium underline underline-offset-4"
                          >
                            Request Return / Refund
                          </button>
                        </div>
                      )}

                      {showReturnForm && orderStatus === 'delivered' && (
                        <div className="pt-4 border-t border-white/10">
                          <p className="text-sm text-gray-300 mb-2 font-medium">Return Reason:</p>
                          <textarea
                            value={returnReason}
                            onChange={(e) => setReturnReason(e.target.value)}
                            placeholder="Please tell us why you want to return this order..."
                            className="w-full bg-luxury-black border border-white/10 rounded-lg px-3 py-2 text-white text-sm placeholder-gray-600 focus:outline-none focus:border-white/30 resize-none h-24 mb-3"
                          />
                          <div className="flex gap-2">
                            <button
                              onClick={() => setShowReturnForm(false)}
                              className="flex-1 px-4 py-2 bg-luxury-black border border-white/10 text-white rounded-lg text-sm hover:bg-white/5"
                            >
                              Cancel
                            </button>
                            <button
                              onClick={handleReturnRequest}
                              disabled={!returnReason.trim()}
                              className="flex-1 px-4 py-2 bg-yellow-500 text-black font-medium disabled:opacity-50 rounded-lg text-sm transition-colors hover:bg-yellow-400"
                            >
                              Submit Request
                            </button>
                          </div>
                        </div>
                      )}

                      {orderStatus === 'return_requested' && (
                         <div className="pt-4 border-t border-white/10 text-center">
                           <p className="text-sm text-yellow-500 font-medium">Return / Refund Requested</p>
                           <p className="text-xs text-gray-400 mt-1">Our support team will review your request shortly.</p>
                         </div>
                      )}

                      {orderStatus === 'returned' && (
                         <div className="pt-4 border-t border-white/10 text-center">
                           <p className="text-sm text-green-500 font-medium">Refund Approved</p>
                           <p className="text-xs text-gray-400 mt-1">Your refund has been processed successfully.</p>
                         </div>
                      )}
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
