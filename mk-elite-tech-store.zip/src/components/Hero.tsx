import { motion } from 'motion/react';
import { useState, useEffect } from 'react';

export default function Hero() {
  const [heroBg, setHeroBg] = useState<{ type: 'image' | 'video', url: string } | null>(null);

  useEffect(() => {
    const loadHeroBg = async () => {
      try {
        const { getFirebaseDoc } = await import('../lib/db');
        const doc = await getFirebaseDoc('config', 'hero_bg');
        if (doc && doc.data) {
          setHeroBg(doc.data);
        } else {
          setHeroBg(null);
        }
      } catch (e) {
        setHeroBg(null);
      }
    };
    loadHeroBg();
    window.addEventListener('hero-bg-updated', loadHeroBg);
    return () => window.removeEventListener('hero-bg-updated', loadHeroBg);
  }, []);

  const defaultImage = "https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?q=80&w=2000";

  return (
    <section id="home" className="relative w-full h-screen min-h-[600px] flex items-center justify-center overflow-hidden bg-black">
      {/* Background Image / Video Overlay */}
      <div className="absolute inset-0 z-0 opacity-40 scale-105 transform hover:scale-100 transition-transform duration-[10s]">
        {heroBg?.type === 'video' ? (
          <video 
            src={heroBg.url}
            autoPlay 
            loop 
            muted 
            playsInline
            className="w-full h-full object-cover"
          />
        ) : (
          <div 
            className="w-full h-full bg-cover bg-center bg-no-repeat"
            style={{ backgroundImage: `url('${heroBg?.url || defaultImage}')` }}
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
        <div className="absolute bottom-0 left-0 right-0 h-40 bg-gradient-to-t from-luxury-black to-transparent"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 text-center pt-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="inline-block mb-4 px-4 py-1.5 rounded-full border border-white/20 bg-white/5 backdrop-blur-sm"
        >
          <span className="text-sm font-medium tracking-wide uppercase text-gray-300">New Collection Live</span>
        </motion.div>
        
        <motion.h1 
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="text-5xl md:text-7xl lg:text-8xl font-display font-bold text-white tracking-tight mb-6"
        >
          Upgrade Your <br className="hidden md:block" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-gray-200 via-white to-gray-500">Tech Lifestyle</span>
        </motion.h1>

        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto mb-10 font-light"
        >
          Premium mobile accessories, smart gadgets & latest tech products designed for the modern minimalists.
        </motion.p>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <a href="#products" className="w-full sm:w-auto px-8 py-4 bg-white text-black font-semibold rounded-full hover:bg-gray-200 transition-colors shadow-[0_0_20px_rgba(255,255,255,0.3)] hover:shadow-[0_0_30px_rgba(255,255,255,0.5)]">
            Shop Now
          </a>
          <a href="#categories" className="w-full sm:w-auto px-8 py-4 bg-transparent border border-white text-white font-semibold rounded-full hover:bg-white hover:text-black transition-colors">
            Explore Products
          </a>
        </motion.div>
      </div>
    </section>
  );
}
