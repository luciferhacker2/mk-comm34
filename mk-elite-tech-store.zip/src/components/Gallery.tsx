import { motion } from 'motion/react';
import { Instagram } from 'lucide-react';
import { useEffect } from 'react';

export default function Gallery() {
  useEffect(() => {
    // Load Elfsight script dynamically
    const script = document.createElement('script');
    script.src = 'https://elfsightcdn.com/platform.js';
    script.async = true;
    document.body.appendChild(script);

    return () => {
      // Optional: Cleanup script if necessary when component unmounts
      if (document.body.contains(script)) {
        document.body.removeChild(script);
      }
    };
  }, []);

  return (
    <section className="py-24 bg-luxury-black text-white relative border-b border-white/5">
      <div className="max-w-[1400px] mx-auto px-4 md:px-6">
        <div className="flex flex-col items-center mb-12 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mb-4"
          >
            <Instagram className="w-5 h-5" />
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-2xl md:text-3xl font-display font-medium tracking-tight"
          >
            #MKCommunication
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-gray-400 mt-2 text-sm"
          >
            Follow our vision on Instagram
          </motion.p>
        </div>

        {/* Elfsight Instagram Feed */}
        <div className="w-full">
          <div className="elfsight-app-c8139b6e-5168-43e9-8978-aadfa179c086" data-elfsight-app-lazy></div>
        </div>
      </div>
    </section>
  );
}
