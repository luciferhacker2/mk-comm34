import { motion, AnimatePresence } from 'motion/react';
import { useState, useEffect } from 'react';
import { CATEGORIES as DEFAULT_CATEGORIES } from '../data';
import { X, ShoppingCart, Heart } from 'lucide-react';
import { useCart } from '../context/CartContext';

export default function Categories() {
  const [categories, setCategories] = useState(DEFAULT_CATEGORIES);
  const [selectedCategory, setSelectedCategory] = useState<any | null>(null);
  const [accessories, setAccessories] = useState<any[]>([]);
  const { addToCart, toggleWishlist, isInWishlist } = useCart();
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    const loadCategories = () => {
      try {
        const c = localStorage.getItem('mk_categories');
        if (c) {
          setCategories(JSON.parse(c));
        } else {
          setCategories(DEFAULT_CATEGORIES);
        }
      } catch(e) {
        setCategories(DEFAULT_CATEGORIES);
      }
    };

    const loadAccessories = () => {
      try {
        const a = localStorage.getItem('mk_accessories');
        if (a) {
          setAccessories(JSON.parse(a));
        }
      } catch(e) {}
    };

    loadCategories();
    loadAccessories();
    window.addEventListener('categories-updated', loadCategories);
    window.addEventListener('accessories-updated', loadAccessories);
    return () => {
      window.removeEventListener('categories-updated', loadCategories);
      window.removeEventListener('accessories-updated', loadAccessories);
    };
  }, []);

  const getAccessoriesForCategory = (categoryId: number) => {
    return accessories.filter(a => a.categoryId === categoryId);
  };

  const handleAddToCart = (product: any) => {
    addToCart(product);
    setToastMessage(`Added ${product.name} to cart`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <section id="categories" className="py-24 bg-luxury-black text-white relative">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex flex-col items-center text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-display font-bold mb-4"
          >
            Featured Categories
          </motion.h2>
          <motion.div 
            initial={{ opacity: 0, scaleX: 0 }}
            whileInView={{ opacity: 1, scaleX: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="h-px w-24 bg-gradient-to-r from-transparent via-white to-transparent"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {categories.map((cat, index) => (
            <motion.div
              key={cat.id}
              onClick={() => setSelectedCategory(cat)}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group relative h-80 rounded-2xl overflow-hidden cursor-pointer border border-white/5 bg-luxury-zinc"
            >
              {cat.type === 'video' ? (
                <video 
                  src={cat.image} // Reusing image field as media URL
                  autoPlay 
                  loop 
                  muted 
                  playsInline
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
              ) : (
                <div 
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-110"
                  style={{ backgroundImage: `url('${cat.image}')` }}
                />
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent transition-opacity duration-300 group-hover:opacity-80" />
              
              <div className="absolute inset-0 p-6 flex flex-col justify-end">
                <h3 className="text-2xl font-display font-semibold mb-2 group-hover:translate-x-2 transition-transform duration-300">
                  {cat.name}
                </h3>
                <span className="text-sm text-gray-300 uppercase tracking-wider opacity-0 transform translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
                  Explore Highlights ✨
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {selectedCategory && (
          <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 sm:p-6 overflow-hidden">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedCategory(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-4xl bg-luxury-zinc border border-white/10 rounded-2xl shadow-2xl flex flex-col max-h-[90vh]"
            >
              <div className="flex items-center justify-between p-6 border-b border-white/10">
                <div>
                  <h2 className="text-2xl font-display font-semibold text-white">{selectedCategory.name} Accessories</h2>
                  <p className="text-sm text-gray-400 mt-1">Enhance your {selectedCategory.name.toLowerCase()} experience.</p>
                </div>
                <button 
                  onClick={() => setSelectedCategory(null)}
                  className="p-2 text-gray-400 hover:text-white transition-colors bg-white/5 rounded-full"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-6 md:p-8 custom-scrollbar">
                {getAccessoriesForCategory(selectedCategory.id).length === 0 ? (
                  <div className="text-center py-12">
                    <p className="text-gray-400 text-lg">No accessories found for this category yet.</p>
                    <button 
                      onClick={() => setSelectedCategory(null)}
                      className="mt-6 px-6 py-2 bg-white/10 text-white rounded-full hover:bg-white/20 transition-colors"
                    >
                      Browse Other Categories
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                    {getAccessoriesForCategory(selectedCategory.id).map(acc => (
                      <div key={acc.id} className="group flex flex-col bg-luxury-black rounded-xl overflow-hidden border border-white/5 hover:border-white/20 transition-colors">
                        <div className="relative aspect-square overflow-hidden bg-white/5">
                          <div 
                            className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
                            style={{ backgroundImage: `url('${acc.image}')` }}
                          />
                        </div>
                        <div className="p-5 flex flex-col flex-grow">
                          <h3 className="text-lg font-medium tracking-tight mb-2 text-white">{acc.name}</h3>
                          <div className="flex items-center justify-between mt-auto">
                            <span className="text-lg font-semibold text-white">₹{acc.price.toLocaleString('en-IN')}</span>
                            <div className="flex gap-2">
                              <button 
                                onClick={() => {
                                  toggleWishlist(acc);
                                  const inWishlist = !isInWishlist(acc.id);
                                  setToastMessage(inWishlist ? `Added to wishlist` : `Removed from wishlist`);
                                  setTimeout(() => setToastMessage(null), 3000);
                                }}
                                className="w-10 h-10 bg-white/5 hover:bg-white/10 text-white rounded-full flex items-center justify-center transition-colors hover:text-red-500"
                              >
                                <Heart className={`w-4 h-4 ${isInWishlist(acc.id) ? 'fill-red-500 text-red-500' : ''}`} />
                              </button>
                              <button 
                                onClick={() => handleAddToCart(acc)}
                                className="w-10 h-10 bg-white text-black rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors"
                              >
                                <ShoppingCart className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {toastMessage && (
        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="fixed bottom-8 right-8 bg-white text-black px-6 py-3 rounded-lg shadow-2xl z-[200] font-medium"
        >
          {toastMessage}
        </motion.div>
      )}
    </section>
  );
}
