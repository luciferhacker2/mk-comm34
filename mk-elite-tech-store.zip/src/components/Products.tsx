import { motion } from 'motion/react';
import { ShoppingCart, Heart, Search } from 'lucide-react';
import { TRENDING_PRODUCTS } from '../data';
import { useCart } from '../context/CartContext';
import { useState, useEffect, useMemo } from 'react';

export default function Products() {
  const { addToCart, toggleWishlist, isInWishlist } = useCart();
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [priceRange, setPriceRange] = useState<string>('all');
  const [accessories, setAccessories] = useState<any[]>([]);

  useEffect(() => {
    const loadAccessories = () => {
      try {
        const a = localStorage.getItem('mk_accessories');
        if (a) {
          setAccessories(JSON.parse(a));
        }
      } catch(e) {}
    };
    loadAccessories();
    window.addEventListener('accessories-updated', loadAccessories);
    return () => {
      window.removeEventListener('accessories-updated', loadAccessories);
    };
  }, []);

  const handleAddToCart = (product: { id: number, name: string, price: number, image: string }) => {
    addToCart(product);
    setToastMessage(`Added ${product.name} to cart`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const filteredItems = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    const combined = [...TRENDING_PRODUCTS];
    accessories.forEach(a => {
      // Avoid duplicate IDs if there's overlap, but accessories have different IDs typically
      // Fallback: just append them
      if (!combined.some(c => c.id === a.id)) {
        combined.push(a);
      }
    });

    let result = combined;

    if (query) {
      result = result.filter(item => item.name.toLowerCase().includes(query));
    }

    if (priceRange === 'under_1000') {
      result = result.filter(item => item.price < 1000);
    } else if (priceRange === '1000_3000') {
      result = result.filter(item => item.price >= 1000 && item.price <= 3000);
    } else if (priceRange === 'above_3000') {
      result = result.filter(item => item.price > 3000);
    }

    return result;
  }, [searchQuery, accessories, priceRange]);

  const [displayCount, setDisplayCount] = useState(16);
  const displayedItems = filteredItems.slice(0, displayCount);

  return (
    <section id="products" className="py-24 bg-luxury-zinc text-white relative">
      {/* Toast Notification */}
      {toastMessage && (
        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="fixed bottom-8 right-8 bg-white text-black px-6 py-3 rounded-lg shadow-2xl z-50 font-medium"
        >
          {toastMessage}
        </motion.div>
      )}

      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12 gap-6">
          <div className="flex w-full flex-col gap-6 lg:flex-row lg:justify-between lg:items-end">
            <div>
              <motion.h2 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="text-3xl md:text-4xl font-display font-bold mb-3"
              >
                Our Products
              </motion.h2>
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="text-gray-400"
              >
                Discover our most sought-after electronics and accessories.
              </motion.p>
            </div>
            
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="w-full lg:w-auto flex flex-col sm:flex-row items-stretch sm:items-center gap-4"
            >
              {/* Category/Price Filters */}
              <div className="flex bg-black/30 border border-white/10 rounded-full p-1 overflow-x-auto custom-scrollbar">
                <button 
                  onClick={() => setPriceRange('all')} 
                  className={`px-4 py-1.5 text-sm rounded-full whitespace-nowrap transition-colors ${priceRange === 'all' ? 'bg-white text-black font-medium' : 'text-gray-400 hover:text-white'}`}
                >
                  All
                </button>
                <button 
                  onClick={() => setPriceRange('under_1000')} 
                  className={`px-4 py-1.5 text-sm rounded-full whitespace-nowrap transition-colors ${priceRange === 'under_1000' ? 'bg-white text-black font-medium' : 'text-gray-400 hover:text-white'}`}
                >
                  Under ₹1K
                </button>
                <button 
                  onClick={() => setPriceRange('1000_3000')} 
                  className={`px-4 py-1.5 text-sm rounded-full whitespace-nowrap transition-colors ${priceRange === '1000_3000' ? 'bg-white text-black font-medium' : 'text-gray-400 hover:text-white'}`}
                >
                  ₹1K - ₹3K
                </button>
                <button 
                  onClick={() => setPriceRange('above_3000')} 
                  className={`px-4 py-1.5 text-sm rounded-full whitespace-nowrap transition-colors ${priceRange === 'above_3000' ? 'bg-white text-black font-medium' : 'text-gray-400 hover:text-white'}`}
                >
                  Above ₹3K
                </button>
              </div>

              {/* Search */}
              <div className="relative flex-1 sm:w-64 sm:flex-none">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  type="text"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2 text-sm border border-white/20 rounded-full bg-black/30 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-white/50 focus:border-transparent transition-all"
                />
              </div>
            </motion.div>
          </div>
        </div>

        {filteredItems.length === 0 ? (
          <div className="text-center py-20 text-gray-400">
            <Search className="w-12 h-12 mx-auto mb-4 opacity-20" />
            <p className="text-xl">No products found matching "{searchQuery}"</p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-12">
              {displayedItems.map((product, index) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-50px" }}
                  transition={{ duration: 0.5, delay: (index % 4) * 0.1 }}
                  className="group flex flex-col"
                >
                {/* Image Container */}
              <div className="relative aspect-[4/5] bg-luxury-black rounded-lg overflow-hidden mb-4">
                {product.badge && (
                  <div className={`absolute top-3 left-3 z-10 px-3 py-1 text-[10px] font-bold uppercase tracking-wider rounded-sm ${product.badgeColor === 'bg-white text-black' ? 'bg-white text-black' : 'bg-gray-800 text-white border border-gray-700'}`}>
                    {product.badge}
                  </div>
                )}
                <div 
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
                  style={{ backgroundImage: `url('${product.image}')` }}
                />
                
                {/* Overlay actions */}
                <div className="absolute md:inset-0 bottom-4 right-4 md:bottom-auto md:right-auto md:bg-black/20 opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-end md:justify-center gap-3 md:gap-4 pointer-events-none md:pointer-events-auto">
                  <div className="relative group/btn pointer-events-auto">
                    <button 
                      onClick={() => handleAddToCart({ id: product.id, name: product.name, price: product.price, image: product.image })}
                      className="w-10 h-10 md:w-12 md:h-12 bg-white text-black rounded-full flex items-center justify-center transform md:translate-y-4 md:group-hover:translate-y-0 transition-all hover:bg-gray-200 shadow-xl"
                    >
                      <ShoppingCart className="w-4 h-4 md:w-5 md:h-5" />
                    </button>
                    <div className="hidden md:block absolute -top-10 left-1/2 -translate-x-1/2 px-3 py-1 bg-black text-white text-xs rounded opacity-0 group-hover/btn:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                      Add to Cart
                      <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-black rotate-45"></div>
                    </div>
                  </div>
                  
                  <div className="relative group/btn pointer-events-auto">
                    <button 
                      onClick={() => {
                        toggleWishlist({ id: product.id, name: product.name, price: product.price, image: product.image });
                        const inWishlist = !isInWishlist(product.id);
                        setToastMessage(inWishlist ? `Added ${product.name} to wishlist` : `Removed ${product.name} from wishlist`);
                        setTimeout(() => setToastMessage(null), 3000);
                      }}
                      className="w-10 h-10 md:w-12 md:h-12 bg-luxury-zinc/80 md:bg-luxury-zinc backdrop-blur-sm md:backdrop-blur-none text-white rounded-full flex items-center justify-center transform md:translate-y-4 md:group-hover:translate-y-0 transition-all delay-75 hover:bg-gray-800 shadow-xl hover:text-red-500"
                    >
                      <Heart className={`w-4 h-4 md:w-5 md:h-5 ${isInWishlist(product.id) ? 'fill-red-500 text-red-500' : ''}`} />
                    </button>
                    <div className="hidden md:block absolute -top-10 left-1/2 -translate-x-1/2 px-3 py-1 bg-black text-white text-xs rounded opacity-0 group-hover/btn:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                      {isInWishlist(product.id) ? 'Remove from Wishlist' : 'Add to Wishlist'}
                      <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-black rotate-45"></div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Info */}
              <div className="flex flex-col flex-grow">
                <h3 className="text-lg font-medium tracking-tight mb-1 group-hover:text-gray-300 transition-colors">
                  {product.name}
                </h3>
                <div className="mt-auto flex items-center gap-3">
                  <span className="text-lg font-semibold">₹{product.price.toLocaleString('en-IN')}</span>
                  {product.originalPrice && (
                    <span className="text-sm text-gray-500 line-through">₹{product.originalPrice.toLocaleString('en-IN')}</span>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        
        {displayCount < filteredItems.length && (
          <div className="flex justify-center mt-12">
            <button 
              onClick={() => setDisplayCount(prev => prev + 16)}
              className="px-8 py-3 bg-white text-black font-medium rounded-full hover:bg-gray-200 transition-colors"
            >
              Load More
            </button>
          </div>
        )}
        </>
        )}
      </div>
    </section>
  );
}
