import { motion, AnimatePresence } from 'motion/react';
import { X, Package, CheckCircle2, Truck, Clock } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';

interface OrderHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function OrderHistoryModal({ isOpen, onClose }: OrderHistoryModalProps) {
  const [orders, setOrders] = useState<any[]>([]);
  const [returnFormOrderId, setReturnFormOrderId] = useState<string | null>(null);
  const [returnReason, setReturnReason] = useState('');
  const { user } = useAuth();
  
  useEffect(() => {
    if (isOpen && user) {
      try {
        const o = localStorage.getItem('mk_orders');
        const allOrders = o ? JSON.parse(o) : [];
        const userOrders = allOrders.filter(
          (order: any) => order.customerEmail === user.email || (user.displayName && order.customerName === user.displayName)
        );
        // Sort by timestamp descending
        userOrders.sort((a: any, b: any) => (b.timestamp || 0) - (a.timestamp || 0));
        setOrders(userOrders);
      } catch (e) {
        setOrders([]);
      }
    }
  }, [isOpen, user]);

  const handleCancelOrder = (orderId: string) => {
    try {
      const o = localStorage.getItem('mk_orders');
      let allOrders = o ? JSON.parse(o) : [];
      let canCancel = true;

      allOrders = allOrders.map((order: any) => {
        if (order.id === orderId) {
          if (order.status === 'shipped' || order.status === 'delivered') {
            canCancel = false;
            return order;
          }
          return { ...order, status: 'cancelled' }
        }
        return order;
      });

      if (!canCancel) {
        // Silently fail or handle internally, avoid window.alert
        return;
      }

      localStorage.setItem('mk_orders', JSON.stringify(allOrders));
      
      setOrders(orders.map(order => 
        order.id === orderId ? { ...order, status: 'cancelled' } : order
      ));
    } catch(e) {}
  };

  const handleReturnRequest = (orderId: string) => {
    if (!returnReason.trim()) return;
    try {
      const o = localStorage.getItem('mk_orders');
      let allOrders = o ? JSON.parse(o) : [];
      let updated = false;

      allOrders = allOrders.map((order: any) => {
        if (order.id === orderId && order.status === 'delivered') {
          updated = true;
          return { ...order, status: 'return_requested', returnReason: returnReason.trim() };
        }
        return order;
      });

      if (updated) {
        localStorage.setItem('mk_orders', JSON.stringify(allOrders));
        setOrders(orders.map(order => 
          order.id === orderId ? { ...order, status: 'return_requested', returnReason: returnReason.trim() } : order
        ));
        setReturnFormOrderId(null);
        setReturnReason('');
      }
    } catch (e) {}
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-2xl bg-luxury-zinc border border-white/10 rounded-2xl p-6 md:p-8 shadow-2xl flex flex-col max-h-[90vh]"
          >
                  <button 
                  onClick={() => {
                    setReturnFormOrderId(null);
                    setReturnReason('');
                    onClose();
                  }}
                  className="absolute top-4 right-4 p-2 text-gray-400 hover:text-white transition-colors bg-black/20 rounded-full z-10"
                >
              <X className="w-5 h-5" />
            </button>
            
            <div className="flex items-center gap-3 mb-6 pb-4 border-b border-white/10">
              <Package className="w-6 h-6 text-white" />
              <h2 className="text-2xl font-display font-medium text-white">Order History</h2>
            </div>
            
            <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar">
              {orders.length === 0 ? (
                <div className="text-center py-12 flex flex-col items-center">
                  <Package className="w-16 h-16 text-white/20 mb-4" />
                  <p className="text-gray-400">You haven't placed any orders yet.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {orders.map((order, idx) => (
                    <div key={idx} className="bg-black/50 border border-white/10 rounded-xl p-5 hover:border-white/30 transition-colors">
                      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-4">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-mono text-sm tracking-wider text-white">{order.id}</span>
                            <span className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider ${
                              order.status === 'delivered' ? 'bg-green-500/20 text-green-400' :
                              order.status === 'returned' ? 'bg-green-500/20 text-green-400' :
                              order.status === 'shipped' ? 'bg-blue-500/20 text-blue-400' :
                              order.status === 'confirmed' ? 'bg-purple-500/20 text-purple-400' :
                              order.status === 'cancelled' ? 'bg-red-500/20 text-red-500' :
                              order.status === 'return_requested' ? 'bg-yellow-500/20 text-yellow-400' :
                              'bg-yellow-500/20 text-yellow-400'
                            }`}>
                              {order.status || 'pending'}
                            </span>
                          </div>
                          <p className="text-xs text-gray-400">
                            {order.timestamp ? new Date(order.timestamp).toLocaleDateString('en-IN', {
                              year: 'numeric', month: 'short', day: 'numeric',
                              hour: '2-digit', minute: '2-digit'
                            }) : 'Unknown date'}
                          </p>
                        </div>
                        <div className="text-left md:text-right">
                          <p className="text-lg font-semibold text-white">₹{order.total?.toLocaleString('en-IN')}</p>
                          <p className="text-xs text-gray-500 uppercase">{order.paymentMethod}</p>
                          {(order.status === 'pending' || order.status === 'confirmed' || !order.status) && (
                            <button 
                              onClick={() => handleCancelOrder(order.id)}
                              className="mt-2 text-xs text-red-400 hover:text-red-300 underline underline-offset-2 block"
                            >
                              Cancel Order
                            </button>
                          )}
                          {order.status === 'delivered' && returnFormOrderId !== order.id && (
                            <button 
                              onClick={() => setReturnFormOrderId(order.id)}
                              className="mt-2 text-xs text-yellow-500 hover:text-yellow-400 underline underline-offset-2 block"
                            >
                              Request Return
                            </button>
                          )}
                        </div>
                      </div>

                      {returnFormOrderId === order.id && order.status === 'delivered' && (
                        <div className="mb-4 pt-4 border-t border-white/5">
                          <p className="text-sm text-gray-300 mb-2 font-medium">Return Reason:</p>
                          <textarea
                            value={returnReason}
                            onChange={(e) => setReturnReason(e.target.value)}
                            placeholder="Please explain why you want to return this order..."
                            className="w-full bg-black border border-white/10 rounded-lg px-3 py-2 text-white text-sm placeholder-gray-600 focus:outline-none focus:border-white/30 resize-none h-20 mb-3"
                          />
                          <div className="flex gap-2 justify-end">
                            <button
                              onClick={() => {
                                setReturnFormOrderId(null);
                                setReturnReason('');
                              }}
                              className="px-4 py-1.5 bg-black border border-white/10 text-white rounded-lg text-xs hover:bg-white/5"
                            >
                              Cancel
                            </button>
                            <button
                              onClick={() => handleReturnRequest(order.id)}
                              disabled={!returnReason.trim()}
                              className="px-4 py-1.5 bg-yellow-500 text-black font-medium disabled:opacity-50 rounded-lg text-xs hover:bg-yellow-400"
                            >
                              Submit Request
                            </button>
                          </div>
                        </div>
                      )}
                      
                      <div className="space-y-2 mt-4 pt-4 border-t border-white/5">
                        <p className="text-xs text-gray-500 uppercase tracking-widest">Items</p>
                        {Array.isArray(order.items) && order.items.map((item: any, i: number) => (
                          <div key={i} className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded bg-white/5 overflow-hidden flex-shrink-0">
                              <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm text-gray-300 truncate">{item.name}</p>
                              <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
