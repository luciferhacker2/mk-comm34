import { useState, useEffect, useRef } from "react";
import {
  Shield,
  Eye,
  Users,
  ShoppingBag,
  X,
  Plus,
  Image as ImageIcon,
  LayoutGrid,
  PackageOpen,
  Star,
} from "lucide-react";
import { CATEGORIES as DEFAULT_CATEGORIES } from "../data";

export default function AdminPanel({ onClose }: { onClose: () => void }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [visits, setVisits] = useState(0);
  const [users, setUsers] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [error, setError] = useState("");

  // Tabs: 'dashboard' | 'categories' | 'accessories' | 'appearance'
  const [activeTab, setActiveTab] = useState<
    "dashboard" | "categories" | "accessories" | "appearance"
  >("dashboard");

  // Categories management
  const [categories, setCategories] = useState<any[]>([]);
  const [newCatName, setNewCatName] = useState("");
  const [newCatImage, setNewCatImage] = useState(""); // Text URL field
  const [newCatType, setNewCatType] = useState("image"); // 'image' or 'video'

  // Accessories management
  const [customAccessories, setCustomAccessories] = useState<any[]>([]);
  const [accessoryDisplayCount, setAccessoryDisplayCount] = useState(20);
  const [accName, setAccName] = useState("");
  const [accImage, setAccImage] = useState("");
  const [accPrice, setAccPrice] = useState("");
  const [accCategoryId, setAccCategoryId] = useState("");

  // Hero management
  const [heroBgType, setHeroBgType] = useState("image");
  const [heroBgUrl, setHeroBgUrl] = useState("");

  // Founder management
  const [founderImage, setFounderImage] = useState("");
  const [founderName, setFounderName] = useState("");
  const [founderTitle, setFounderTitle] = useState("");
  const [founderQuote, setFounderQuote] = useState("");

  const [testimonials, setTestimonials] = useState<any[]>([]);

  useEffect(() => {
    const v = localStorage.getItem("mk_visits");
    setVisits(v ? parseInt(v) : 0);

    const u = localStorage.getItem("mk_users");
    setUsers(u ? JSON.parse(u) : []);

    const o = localStorage.getItem("mk_orders");
    setOrders(o ? JSON.parse(o) : []);

    const c = localStorage.getItem("mk_categories");
    setCategories(c ? JSON.parse(c) : DEFAULT_CATEGORIES);

    const a = localStorage.getItem("mk_accessories");
    setCustomAccessories(a ? JSON.parse(a) : []);

    const h = localStorage.getItem("mk_hero_bg");
    if (h) {
      const parsed = JSON.parse(h);
      setHeroBgType(parsed.type || "image");
      setHeroBgUrl(parsed.url || "");
    }

    const f = localStorage.getItem("mk_founder");
    if (f) {
      const parsed = JSON.parse(f);
      setFounderImage(parsed.image || "");
      setFounderName(parsed.name || "");
      setFounderTitle(parsed.title || "");
      setFounderQuote(parsed.quote || "");
    }

    const t = localStorage.getItem("mk_testimonials");
    if (t) {
      setTestimonials(JSON.parse(t));
    }
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === "veronica@0321") {
      setIsAuthenticated(true);
      setError("");
    } else {
      setError("Invalid admin password");
    }
  };

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName || !newCatImage) return;

    const newCat = {
      id: Date.now(),
      name: newCatName,
      image: newCatImage,
      type: newCatType,
    };

    const updated = [newCat, ...categories];
    setCategories(updated);
    localStorage.setItem("mk_categories", JSON.stringify(updated));

    setNewCatName("");
    setNewCatImage("");

    // Dispatch custom event so Category.tsx knows to refresh without reload
    window.dispatchEvent(new Event("categories-updated"));
  };

  const deleteCategory = (id: number) => {
    const updated = categories.filter((c) => c.id !== id);
    setCategories(updated);
    localStorage.setItem("mk_categories", JSON.stringify(updated));
    window.dispatchEvent(new Event("categories-updated"));
  };

  const handleUpdateHero = (e: React.FormEvent) => {
    e.preventDefault();
    const data = { type: heroBgType, url: heroBgUrl };
    localStorage.setItem("mk_hero_bg", JSON.stringify(data));
    window.dispatchEvent(new Event("hero-bg-updated"));
    alert("Hero background updated successfully!");
  };

  const handleUpdateFounder = (e: React.FormEvent) => {
    e.preventDefault();
    const data = {
      image: founderImage,
      name: founderName,
      title: founderTitle,
      quote: founderQuote,
    };
    localStorage.setItem("mk_founder", JSON.stringify(data));
    window.dispatchEvent(new Event("founder-updated"));
    alert("Founder details updated successfully!");
  };

  const handleAddAccessory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accName || !accImage || !accPrice || !accCategoryId) return;

    const newAcc = {
      id: Date.now(),
      categoryId: parseInt(accCategoryId),
      name: accName,
      price: parseInt(accPrice),
      image: accImage,
    };

    const updated = [newAcc, ...customAccessories];
    setCustomAccessories(updated);
    localStorage.setItem("mk_accessories", JSON.stringify(updated));

    setAccName("");
    setAccImage("");
    setAccPrice("");
    setAccCategoryId("");
    window.dispatchEvent(new Event("accessories-updated"));
  };

  const updateOrderStatus = (orderId: string, newStatus: string) => {
    const updated = orders.map((o) =>
      o.id === orderId ? { ...o, status: newStatus } : o,
    );
    setOrders(updated);
    localStorage.setItem("mk_orders", JSON.stringify(updated));
  };

  const deleteAccessory = (id: number) => {
    const updated = customAccessories.filter((a) => a.id !== id);
    setCustomAccessories(updated);
    localStorage.setItem("mk_accessories", JSON.stringify(updated));
    window.dispatchEvent(new Event("accessories-updated"));
  };

  const deleteTestimonial = (id: number) => {
    const updated = testimonials.filter((t) => t.id !== id);
    setTestimonials(updated);
    localStorage.setItem("mk_testimonials", JSON.stringify(updated));
    window.dispatchEvent(new Event("testimonials-updated"));
  };

  if (!isAuthenticated) {
    return (
      <div className="fixed inset-0 z-[200] bg-luxury-black/90 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="bg-luxury-zinc border border-white/10 rounded-2xl p-8 w-full max-w-sm relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex justify-center mb-6 text-white">
            <Shield className="w-12 h-12" />
          </div>
          <h2 className="text-2xl font-display text-white text-center mb-6">
            Admin Access
          </h2>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
                className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30"
              />
              {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
            </div>
            <button className="w-full bg-white text-black font-semibold rounded-lg py-3 hover:bg-gray-200">
              Access Admin
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[200] bg-luxury-black overflow-y-auto">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-display text-white flex items-center gap-3">
            <Shield className="w-8 h-8" />
            MK Command Center
          </h1>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white flex items-center gap-2 px-4 py-2 bg-luxury-zinc border border-white/10 rounded-lg"
          >
            <X className="w-5 h-5" /> Exit Admin
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-4 mb-8 border-b border-white/10 pb-4 overflow-x-auto custom-scrollbar">
          <button
            onClick={() => setActiveTab("dashboard")}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${activeTab === "dashboard" ? "bg-white text-black" : "text-gray-400 hover:text-white"}`}
          >
            <LayoutGrid className="w-4 h-4" /> Dashboard
          </button>
          <button
            onClick={() => setActiveTab("categories")}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${activeTab === "categories" ? "bg-white text-black" : "text-gray-400 hover:text-white"}`}
          >
            <PackageOpen className="w-4 h-4" /> Categories
          </button>
          <button
            onClick={() => setActiveTab("accessories")}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${activeTab === "accessories" ? "bg-white text-black" : "text-gray-400 hover:text-white"}`}
          >
            <ShoppingBag className="w-4 h-4" /> Accessories
          </button>
          <button
            onClick={() => setActiveTab("appearance")}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${activeTab === "appearance" ? "bg-white text-black" : "text-gray-400 hover:text-white"}`}
          >
            <ImageIcon className="w-4 h-4" /> Appearance & Ads
          </button>
          <button
            onClick={() => setActiveTab("reviews")}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${activeTab === "reviews" ? "bg-white text-black" : "text-gray-400 hover:text-white"}`}
          >
            <Star className="w-4 h-4" /> Reviews
          </button>
        </div>

        {activeTab === "dashboard" && (
          <>
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <div className="bg-luxury-zinc border border-white/5 rounded-2xl p-6 flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-500/10 rounded-full flex items-center justify-center text-blue-500">
                  <Eye className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Total Views</p>
                  <p className="text-3xl font-semibold text-white">{visits}</p>
                </div>
              </div>
              <div className="bg-luxury-zinc border border-white/5 rounded-2xl p-6 flex items-center gap-4">
                <div className="w-12 h-12 bg-green-500/10 rounded-full flex items-center justify-center text-green-500">
                  <ShoppingBag className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Total Orders</p>
                  <p className="text-3xl font-semibold text-white">
                    {orders.length}
                  </p>
                </div>
              </div>
              <div className="bg-luxury-zinc border border-white/5 rounded-2xl p-6 flex items-center gap-4">
                <div className="w-12 h-12 bg-purple-500/10 rounded-full flex items-center justify-center text-purple-500">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Registered Logins</p>
                  <p className="text-3xl font-semibold text-white">
                    {users.length}
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Orders Table */}
              <div className="bg-luxury-zinc border border-white/5 rounded-2xl p-6 overflow-hidden flex flex-col max-h-[600px]">
                <h2 className="text-xl font-display text-white mb-6">
                  Recent Orders
                </h2>
                <div className="overflow-y-auto pr-2 custom-scrollbar">
                  {orders.length === 0 ? (
                    <p className="text-gray-400 text-center py-8">
                      No orders yet.
                    </p>
                  ) : (
                    <div className="space-y-4">
                      {orders
                        .slice()
                        .reverse()
                        .map((order, i) => (
                          <div
                            key={i}
                            className="bg-black/50 border border-white/5 rounded-xl p-4"
                          >
                            <div className="flex justify-between items-start mb-3">
                              <div>
                                <p className="text-white font-medium">
                                  {order.customerName}
                                </p>
                                <p className="text-sm text-gray-400">
                                  {order.customerPhone}
                                </p>
                                <p className="text-xs text-gray-500 mt-1">
                                  ID: {order.id}
                                </p>
                              </div>
                              <div className="text-right">
                                <p className="text-lg font-semibold text-white">
                                  ₹{order.total}
                                </p>
                                <span className="text-xs px-2 py-1 bg-white/10 rounded text-gray-300 uppercase">
                                  {order.paymentMethod}
                                </span>
                              </div>
                            </div>
                            <div className="text-sm text-gray-400 mb-3">
                              <p>{order.address}</p>
                              <p>
                                {order.city}, {order.state}
                              </p>
                            </div>
                            <div className="mb-3 flex items-center justify-between">
                              <label className="text-xs text-gray-400 uppercase">
                                Status:
                              </label>
                              <select
                                value={order.status || "pending"}
                                onChange={(e) =>
                                  updateOrderStatus(order.id, e.target.value)
                                }
                                className="bg-black border border-white/20 rounded px-2 py-1 text-sm text-white focus:outline-none"
                              >
                                <option value="pending">Pending</option>
                                <option value="confirmed">Confirmed</option>
                                <option value="shipped">Shipped</option>
                                <option value="delivered">Delivered</option>
                                <option value="cancelled">Cancelled</option>
                                <option value="return_requested">
                                  Return Requested
                                </option>
                                <option value="returned">
                                  Returned / Refunded
                                </option>
                              </select>
                            </div>

                            {order.status === "return_requested" &&
                              order.returnReason && (
                                <div className="mb-4 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                                  <p className="text-yellow-500 text-xs font-medium uppercase mb-1">
                                    Return Request Reason
                                  </p>
                                  <p className="text-sm text-gray-300 italic">
                                    "{order.returnReason}"
                                  </p>
                                  <div className="flex gap-2 mt-3">
                                    <button
                                      onClick={() =>
                                        updateOrderStatus(order.id, "returned")
                                      }
                                      className="px-3 py-1.5 bg-green-500/20 text-green-400 text-xs font-medium rounded hover:bg-green-500/30 transition-colors"
                                    >
                                      Approve Refund
                                    </button>
                                    <button
                                      onClick={() =>
                                        updateOrderStatus(order.id, "delivered")
                                      }
                                      className="px-3 py-1.5 bg-red-500/20 text-red-400 text-xs font-medium rounded hover:bg-red-500/30 transition-colors"
                                    >
                                      Reject Request
                                    </button>
                                  </div>
                                </div>
                              )}

                            <div className="border-t border-white/10 pt-3">
                              <p className="text-xs text-gray-500 mb-2 uppercase">
                                Items Ordered:
                              </p>
                              <ul className="space-y-1">
                                {order.items.map((item: any, j: number) => (
                                  <li
                                    key={j}
                                    className="text-sm text-gray-300 flex justify-between"
                                  >
                                    <span>
                                      {item.quantity}x {item.name}
                                    </span>
                                    <span>₹{item.price * item.quantity}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                            <p className="text-xs text-gray-500 mt-4">
                              {new Date(order.timestamp).toLocaleString()}
                            </p>
                          </div>
                        ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Users Table */}
              <div className="bg-luxury-zinc border border-white/5 rounded-2xl p-6 overflow-hidden flex flex-col max-h-[600px]">
                <h2 className="text-xl font-display text-white mb-6">
                  User Logins
                </h2>
                <div className="overflow-y-auto pr-2 custom-scrollbar">
                  {users.length === 0 ? (
                    <p className="text-gray-400 text-center py-8">
                      No logins recorded yet.
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {users
                        .slice()
                        .reverse()
                        .map((u, i) => (
                          <div
                            key={i}
                            className="flex items-center gap-4 bg-black/50 border border-white/5 rounded-xl p-4"
                          >
                            <img
                              src={u.photoURL}
                              alt={u.displayName}
                              className="w-10 h-10 rounded-full"
                            />
                            <div>
                              <p className="text-white font-medium">
                                {u.displayName}
                              </p>
                              <p className="text-sm text-gray-400">{u.email}</p>
                              <p className="text-xs text-gray-500 mt-1">
                                First seen:{" "}
                                {new Date(u.timestamp).toLocaleString()}
                              </p>
                            </div>
                          </div>
                        ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </>
        )}

        {activeTab === "categories" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Add New Category */}
            <div className="lg:col-span-1 bg-luxury-zinc border border-white/5 rounded-2xl p-6 h-fit">
              <h2 className="text-xl font-display text-white mb-6">
                Add Custom Category
              </h2>
              <p className="text-xs text-gray-400 mb-6">
                Create new categories by pasting direct image links to avoid
                upload limits and bandwidth usage.
              </p>

              <form onSubmit={handleAddCategory} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Category Name
                  </label>
                  <input
                    type="text"
                    required
                    value={newCatName}
                    onChange={(e) => setNewCatName(e.target.value)}
                    placeholder="e.g. Speakers"
                    className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Media URL
                  </label>
                  <input
                    type="url"
                    required
                    value={newCatImage}
                    onChange={(e) => setNewCatImage(e.target.value)}
                    placeholder="https://example.com/image.jpg OR video.mp4"
                    className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30"
                  />
                  {newCatImage && newCatType === "image" && (
                    <div className="mt-4 p-4 border border-white/10 rounded-lg text-center">
                      <img
                        src={newCatImage}
                        alt="Preview"
                        onError={(e) => {
                          e.currentTarget.style.display = "none";
                        }}
                        onLoad={(e) => {
                          e.currentTarget.style.display = "block";
                        }}
                        className="w-20 h-20 object-cover rounded-lg mx-auto mb-2"
                      />
                      <p className="text-xs text-green-400">
                        Image link preview
                      </p>
                    </div>
                  )}
                  {newCatImage && newCatType === "video" && (
                    <div className="mt-4 p-4 border border-white/10 rounded-lg text-center">
                      <video
                        src={newCatImage}
                        className="w-20 h-20 object-cover rounded-lg mx-auto mb-2"
                        controls
                      />
                      <p className="text-xs text-green-400">Video preview</p>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Media Type
                  </label>
                  <select
                    value={newCatType}
                    onChange={(e) => setNewCatType(e.target.value)}
                    className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none"
                  >
                    <option value="image">Image</option>
                    <option value="video">Video</option>
                  </select>
                </div>

                <button
                  type="submit"
                  disabled={!newCatName || !newCatImage}
                  className="w-full bg-white text-black font-semibold rounded-lg py-3 flex items-center justify-center gap-2 hover:bg-gray-200 disabled:opacity-50 transition-colors"
                >
                  <Plus className="w-5 h-5" /> Add Category
                </button>
              </form>
            </div>

            {/* List Categories */}
            <div className="lg:col-span-2 bg-luxury-zinc border border-white/5 rounded-2xl p-6">
              <h2 className="text-xl font-display text-white mb-6">
                Current Categories
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {categories.map((cat, i) => {
                  return (
                    <div
                      key={cat.id}
                      className="group relative rounded-xl overflow-hidden h-32 border border-white/5 bg-black"
                    >
                      {cat.type === "video" ? (
                        <video
                          src={cat.image}
                          className="absolute inset-0 w-full h-full object-cover"
                          muted
                        />
                      ) : (
                        <div
                          className="absolute inset-0 bg-cover bg-center"
                          style={{ backgroundImage: `url('${cat.image}')` }}
                        />
                      )}
                      <div className="absolute inset-0 bg-black/60 group-hover:bg-black/50 transition-colors" />
                      <div className="absolute inset-0 p-4 flex flex-col justify-between">
                        <div className="flex justify-between items-start">
                          <button
                            onClick={() => deleteCategory(cat.id)}
                            className="w-6 h-6 bg-red-500/80 text-white rounded-full flex items-center justify-center hover:bg-red-500 transition-colors ml-auto"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                        <h3 className="text-white font-medium drop-shadow-lg">
                          {cat.name}
                        </h3>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {activeTab === "accessories" && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1 bg-luxury-zinc border border-white/5 rounded-2xl p-6 h-fit">
              <h2 className="text-xl font-display text-white mb-6">
                Add Accessory
              </h2>
              <p className="text-xs text-gray-400 mb-6">
                Add products with image links to avoid upload limits.
              </p>

              <form onSubmit={handleAddAccessory} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Category
                  </label>
                  <select
                    required
                    value={accCategoryId}
                    onChange={(e) => setAccCategoryId(e.target.value)}
                    className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30"
                  >
                    <option value="" disabled>
                      Select Category
                    </option>
                    {categories.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    required
                    value={accName}
                    onChange={(e) => setAccName(e.target.value)}
                    placeholder="e.g. Wireless Earbuds"
                    className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Price (₹)
                  </label>
                  <input
                    type="number"
                    required
                    value={accPrice}
                    onChange={(e) => setAccPrice(e.target.value)}
                    placeholder="e.g. 1999"
                    className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Image URL
                  </label>
                  <input
                    type="url"
                    required
                    value={accImage}
                    onChange={(e) => setAccImage(e.target.value)}
                    placeholder="https://example.com/image.jpg"
                    className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30"
                  />
                  {accImage && (
                    <div className="mt-4 p-4 border border-white/10 rounded-lg text-center">
                      <img
                        src={accImage}
                        alt="Preview"
                        onError={(e) => {
                          e.currentTarget.style.display = "none";
                        }}
                        onLoad={(e) => {
                          e.currentTarget.style.display = "block";
                        }}
                        className="w-20 h-20 object-cover rounded-lg mx-auto mb-2"
                      />
                    </div>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={
                    !accName || !accImage || !accPrice || !accCategoryId
                  }
                  className="w-full bg-white text-black font-semibold rounded-lg py-3 flex items-center justify-center gap-2 hover:bg-gray-200 disabled:opacity-50 transition-colors"
                >
                  <Plus className="w-5 h-5" /> Add Accessory
                </button>
              </form>
            </div>

            <div className="lg:col-span-2 bg-luxury-zinc border border-white/5 rounded-2xl p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-display text-white">
                  Current Accessories ({customAccessories.length})
                </h2>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {customAccessories.length === 0 ? (
                  <p className="text-gray-400">No accessories added yet.</p>
                ) : (
                  <>
                    {customAccessories.slice(0, accessoryDisplayCount).map((acc) => {
                      const category = categories.find(
                        (c) => c.id === acc.categoryId,
                      );
                      return (
                        <div
                          key={acc.id}
                          className="group relative rounded-xl overflow-hidden bg-black/50 border border-white/5 p-4 flex gap-4"
                        >
                          <img
                            src={acc.image}
                            alt={acc.name}
                            loading="lazy"
                            className="w-20 h-20 object-cover rounded-lg"
                          />
                          <div className="flex-1 overflow-hidden">
                            <h3 className="text-white font-medium truncate">{acc.name}</h3>
                            <p className="text-sm text-gray-400">₹{acc.price}</p>
                            <p className="text-xs text-gray-500 mt-1 truncate">
                              {category?.name || "Unknown Category"}
                            </p>
                          </div>
                          <button
                            onClick={() => deleteAccessory(acc.id)}
                            className="w-8 h-8 flex-shrink-0 bg-red-500/10 text-red-500 rounded-lg flex items-center justify-center hover:bg-red-500 hover:text-white transition-colors"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      );
                    })}
                  </>
                )}
              </div>
              {customAccessories.length > accessoryDisplayCount && (
                <div className="mt-6 flex justify-center">
                  <button
                    onClick={() => setAccessoryDisplayCount(prev => prev + 20)}
                    className="px-6 py-2 bg-white/10 text-white rounded-lg hover:bg-white/20 transition-colors"
                  >
                    Load More Accessories
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === "appearance" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-luxury-zinc border border-white/5 rounded-2xl p-6 h-fit">
              <h2 className="text-xl font-display text-white mb-6">
                Hero Background
              </h2>
              <p className="text-xs text-gray-400 mb-6">
                Update the main background visual for the homepage. Accepts
                image or video URL.
              </p>

              <form onSubmit={handleUpdateHero} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Media URL
                  </label>
                  <input
                    type="url"
                    required
                    value={heroBgUrl}
                    onChange={(e) => setHeroBgUrl(e.target.value)}
                    placeholder="https://example.com/video.mp4"
                    className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30"
                  />
                  {heroBgUrl && heroBgType === "image" && (
                    <div className="mt-4 p-4 border border-white/10 rounded-lg text-center bg-black">
                      <img
                        src={heroBgUrl}
                        alt="Preview"
                        onError={(e) => {
                          e.currentTarget.style.display = "none";
                        }}
                        onLoad={(e) => {
                          e.currentTarget.style.display = "block";
                        }}
                        className="w-full h-32 object-cover rounded-lg mx-auto mb-2"
                      />
                    </div>
                  )}
                  {heroBgUrl && heroBgType === "video" && (
                    <div className="mt-4 p-4 border border-white/10 rounded-lg text-center bg-black">
                      <video
                        src={heroBgUrl}
                        autoPlay
                        loop
                        muted
                        className="w-full h-32 object-cover rounded-lg mx-auto mb-2"
                      />
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Media Type
                  </label>
                  <select
                    value={heroBgType}
                    onChange={(e) => setHeroBgType(e.target.value)}
                    className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none"
                  >
                    <option value="image">Image</option>
                    <option value="video">Video</option>
                  </select>
                </div>

                <button
                  type="submit"
                  disabled={!heroBgUrl}
                  className="w-full bg-white text-black font-semibold rounded-lg py-3 flex items-center justify-center gap-2 hover:bg-gray-200 disabled:opacity-50 transition-colors"
                >
                  <ImageIcon className="w-5 h-5" /> Update Hero Visual
                </button>
              </form>
            </div>

            <div className="bg-luxury-zinc border border-white/5 rounded-2xl p-6 h-fit">
              <h2 className="text-xl font-display text-white mb-6">
                Founder Information
              </h2>
              <p className="text-xs text-gray-400 mb-6">
                Update the details shown in the Founder section.
              </p>

              <form onSubmit={handleUpdateFounder} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Image URL
                  </label>
                  <input
                    type="url"
                    value={founderImage}
                    onChange={(e) => setFounderImage(e.target.value)}
                    placeholder="https://example.com/founder.jpg"
                    className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    value={founderName}
                    onChange={(e) => setFounderName(e.target.value)}
                    placeholder="Mr. Founder"
                    className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Title
                  </label>
                  <input
                    type="text"
                    value={founderTitle}
                    onChange={(e) => setFounderTitle(e.target.value)}
                    placeholder="Founder & CEO"
                    className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Quote / Message
                  </label>
                  <textarea
                    value={founderQuote}
                    onChange={(e) => setFounderQuote(e.target.value)}
                    placeholder="A short message from the founder..."
                    rows={4}
                    className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30 resize-none"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-white text-black font-semibold rounded-lg py-3 flex items-center justify-center gap-2 hover:bg-gray-200 transition-colors"
                >
                  <Users className="w-5 h-5" /> Update Founder Details
                </button>
              </form>
            </div>
          </div>
        )}

        {activeTab === "reviews" && (
          <div className="bg-luxury-zinc border border-white/5 rounded-2xl p-6">
            <h2 className="text-xl font-display text-white mb-6">
              Manage Reviews
            </h2>
            <div className="space-y-4">
              {testimonials.length === 0 ? (
                <p className="text-gray-400 text-center py-8">
                  No reviews yet.
                </p>
              ) : (
                testimonials.map((t) => (
                  <div
                    key={t.id}
                    className="bg-black/50 border border-white/5 rounded-xl p-4 flex gap-4"
                  >
                    <img
                      src={t.image}
                      alt={t.name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <h3 className="text-white font-medium">
                        {t.name}{" "}
                        <span className="text-xs text-gray-500 font-normal">
                          ({t.role})
                        </span>
                      </h3>
                      <div className="flex gap-1 text-yellow-500 my-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-3 h-3 ${i < t.rating ? "fill-current" : "text-gray-700"}`}
                          />
                        ))}
                      </div>
                      <p className="text-sm text-gray-300 italic mt-2">
                        "{t.content}"
                      </p>
                    </div>
                    <button
                      onClick={() => deleteTestimonial(t.id)}
                      className="w-8 h-8 flex-shrink-0 bg-red-500/10 text-red-500 rounded-lg flex items-center justify-center hover:bg-red-500 hover:text-white transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
