import { motion, AnimatePresence } from 'motion/react';
import { X, Check } from 'lucide-react';
import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { stateCityMap } from '../data/indianStatesCities';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  total: number;
}

export default function CheckoutModal({ isOpen, onClose, total }: CheckoutModalProps) {
  const [step, setStep] = useState<1 | 2>(1); // 1 = Details, 2 = Success
  const [paymentMethod, setPaymentMethod] = useState('upi');
  const [selectedState, setSelectedState] = useState('');
  const [placedOrderId, setPlacedOrderId] = useState<string | null>(null);
  const { cartItems } = useCart(); // Keep for future if needed to clear
  const { user } = useAuth();
  
  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    
    // Simple way to grab inputs since we don't have separate state for them
    const inputs = form.querySelectorAll('input, select');
    let customerName = '';
    let customerPhone = '';
    let address = '';
    let city = '';
    let state = selectedState;

    // Simulate payment processing
    setTimeout(() => {
      setStep(2);
      
      form.querySelectorAll('input, select').forEach((input: any) => {
        if(input.placeholder === 'Full Name') customerName = input.value;
        if(input.placeholder === 'Mobile Number') customerPhone = input.value;
        if(input.placeholder === 'House No. / Building Name') address = input.value;
        // In the select, the first one is disabled so it doesn't match a text input, but we can do it like this:
      });
      const selects = form.querySelectorAll('select');
      if (selects.length >= 2) {
        city = selects[0].value;
        state = selects[1].value;
      }
      
      try {
        const o = localStorage.getItem('mk_orders');
        const mkOrders = o ? JSON.parse(o) : [];
        const newOrderId = 'MK' + Math.floor(Math.random() * 1000000);
        mkOrders.push({
          id: newOrderId,
          customerName,
          customerPhone,
          customerEmail: user?.email || '',
          address,
          city,
          state,
          paymentMethod,
          status: 'pending',
          total: finalTotal,
          items: cartItems,
          timestamp: Date.now()
        });
        localStorage.setItem('mk_orders', JSON.stringify(mkOrders));
        setPlacedOrderId(newOrderId);
      } catch(e) {}
    }, 1500);
  };

  const closeAndReset = () => {
    onClose();
    setTimeout(() => {
      setStep(1);
      setPaymentMethod('upi');
      setSelectedState('');
      setPlacedOrderId(null);
    }, 500); 
  };

  const finalTotal = paymentMethod === 'cod' ? total + 99 : total;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center px-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeAndReset}
            className="absolute inset-0 bg-black/80 backdrop-blur-md"
          />
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-2xl bg-luxury-zinc border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
          >
            <button 
              onClick={closeAndReset}
              className="absolute top-4 right-4 p-2 text-gray-400 hover:text-white transition-colors z-10 bg-black/20 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>

            {step === 1 ? (
              <div className="flex flex-col md:flex-row h-full overflow-y-auto">
                {/* Left Side - Details */}
                <div className="flex-1 p-8 border-b md:border-b-0 md:border-r border-white/5 bg-luxury-zinc flex flex-col">
                  <div>
                    <h3 className="text-2xl font-display font-medium text-white mb-2">Secure Checkout</h3>
                    <p className="text-gray-400 text-sm mb-8">Enter your payment details below.</p>
                  </div>
                  
                  <form id="checkout-form" onSubmit={handlePaymentSubmit} className="space-y-6 flex-1">
                    <div>
                      <label className="block text-xs font-semibold text-gray-400 uppercase tracking-widest mb-3">Payment Method</label>
                      <div className="grid grid-cols-2 gap-3">
                        <label className={`flex items-center gap-3 p-3 bg-luxury-black border rounded-lg cursor-pointer transition-colors ${paymentMethod === 'upi' ? 'border-white/50' : 'border-white/10 hover:border-white/30'}`}>
                          <input type="radio" name="payment" value="upi" checked={paymentMethod === 'upi'} onChange={(e) => setPaymentMethod(e.target.value)} className="text-white bg-black border-white/20" />
                          <span className="text-sm font-medium">UPI</span>
                        </label>
                        <label className={`flex items-center gap-3 p-3 bg-luxury-black border rounded-lg cursor-pointer transition-colors ${paymentMethod === 'gpay' ? 'border-white/50' : 'border-white/10 hover:border-white/30'}`}>
                          <input type="radio" name="payment" value="gpay" checked={paymentMethod === 'gpay'} onChange={(e) => setPaymentMethod(e.target.value)} className="text-white bg-black border-white/20" />
                          <span className="text-sm font-medium">Google Pay</span>
                        </label>
                        <label className={`flex items-center gap-3 p-3 bg-luxury-black border rounded-lg cursor-pointer transition-colors ${paymentMethod === 'phonepe' ? 'border-white/50' : 'border-white/10 hover:border-white/30'}`}>
                          <input type="radio" name="payment" value="phonepe" checked={paymentMethod === 'phonepe'} onChange={(e) => setPaymentMethod(e.target.value)} className="text-white bg-black border-white/20" />
                          <span className="text-sm font-medium">PhonePe</span>
                        </label>
                        <label className={`flex items-center gap-3 p-3 bg-luxury-black border rounded-lg cursor-pointer transition-colors ${paymentMethod === 'cod' ? 'border-white/50' : 'border-white/10 hover:border-white/30'}`}>
                          <input type="radio" name="payment" value="cod" checked={paymentMethod === 'cod'} onChange={(e) => setPaymentMethod(e.target.value)} className="text-white bg-black border-white/20" />
                          <div className="flex flex-col">
                            <span className="text-sm font-medium">Cash on Delivery</span>
                            {paymentMethod === 'cod' && (
                              <span className="text-xs text-red-400 mt-0.5">+₹99 extra charge</span>
                            )}
                          </div>
                        </label>
                      </div>
                      {paymentMethod === 'upi' && (
                        <div className="mt-4">
                          <input 
                            type="text" 
                            required
                            placeholder="Enter UPI ID (e.g. name@upi)" 
                            className="w-full bg-luxury-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30 transition-colors"
                          />
                        </div>
                      )}
                    </div>
                    
                    <div className="pt-4 border-t border-white/5">
                      <label className="block text-xs font-semibold text-gray-400 uppercase tracking-widest mb-3">Shipping Information</label>
                      <div className="flex flex-col gap-3">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <input 
                            type="text" 
                            required
                            placeholder="Full Name" 
                            className="w-full bg-luxury-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30 transition-colors"
                          />
                          <input 
                            type="tel" 
                            required
                            placeholder="Mobile Number" 
                            className="w-full bg-luxury-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30 transition-colors"
                          />
                        </div>
                        <input 
                          type="text" 
                          required
                          placeholder="House No. / Building Name" 
                          className="w-full bg-luxury-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30 transition-colors"
                        />
                        <input 
                          type="text" 
                          placeholder="Landmark (Optional)" 
                          className="w-full bg-luxury-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30 transition-colors"
                        />
                        <div className="grid grid-cols-2 gap-3">
                          <select 
                            required
                            defaultValue=""
                            className="w-full bg-luxury-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30 transition-colors appearance-none"
                            disabled={!selectedState}
                          >
                            <option value="" disabled>Select City</option>
                            {selectedState && stateCityMap[selectedState]?.map((city) => (
                              <option key={city} value={city}>{city}</option>
                            ))}
                          </select>
                          <select 
                            required
                            value={selectedState}
                            onChange={(e) => setSelectedState(e.target.value)}
                            className="w-full bg-luxury-black border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-white/30 transition-colors appearance-none"
                          >
                            <option value="" disabled>Select State</option>
                            {Object.keys(stateCityMap).map((stateName) => (
                              <option key={stateName} value={stateName}>{stateName}</option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>

                {/* Right Side - Summary */}
                <div className="w-full md:w-72 bg-luxury-black p-8 flex flex-col justify-between">
                   <div>
                      <h4 className="font-semibold text-white mb-6 tracking-wide">Order Summary</h4>
                      <div className="space-y-4 text-sm">
                        <div className="flex justify-between text-gray-400">
                          <span>Subtotal</span>
                          <span>₹{total.toLocaleString('en-IN')}</span>
                        </div>
                        <div className="flex justify-between text-gray-400">
                          <span>Shipping</span>
                          <span>{paymentMethod === 'cod' ? '+₹99' : 'Free'}</span>
                        </div>
                        <div className="flex justify-between text-white font-medium pt-4 border-t border-white/10 text-lg">
                          <span>Total</span>
                          <span>₹{finalTotal.toLocaleString('en-IN')}</span>
                        </div>
                      </div>
                   </div>

                   <button 
                      form="checkout-form"
                      type="submit"
                      className="w-full bg-white text-black font-semibold rounded-lg py-4 mt-8 hover:bg-gray-200 transition-all shadow-[0_0_20px_rgba(255,255,255,0.1)] hover:shadow-[0_0_30px_rgba(255,255,255,0.2)]"
                    >
                      {paymentMethod === 'cod' ? `Place Order • ₹${finalTotal.toLocaleString('en-IN')}` : `Pay ₹${finalTotal.toLocaleString('en-IN')}`}
                    </button>
                </div>
              </div>
            ) : (
              <div className="p-12 flex flex-col items-center justify-center text-center h-full min-h-[400px]">
                <motion.div 
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", damping: 15 }}
                  className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mb-6"
                >
                  <Check className="w-10 h-10 text-black border-4 border-black rounded-full p-1" />
                </motion.div>
                <h3 className="text-3xl font-display font-bold text-white mb-3">Order Confirmed</h3>
                {placedOrderId && (
                  <p className="text-white font-mono text-xl mb-3 bg-black/30 py-2 px-4 rounded-lg border border-white/10 tracking-widest">
                    {placedOrderId}
                  </p>
                )}
                <p className="text-gray-400 text-lg mb-8 max-w-sm font-light">
                  Thank you for your purchase. Please keep your Order ID safe to track your order.
                </p>
                <button 
                  onClick={closeAndReset}
                  className="px-8 py-3 bg-white text-black font-semibold rounded-full hover:bg-gray-200 transition-colors"
                >
                  Return to Store
                </button>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
