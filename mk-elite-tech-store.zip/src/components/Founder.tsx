import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import { Quote } from 'lucide-react';

export default function Founder() {
  const [founderData, setFounderData] = useState({
    image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=1000',
    name: 'Mr. Founder',
    title: 'Founder & CEO, MK Communication',
    quote: 'Our vision is to elevate the tech lifestyle by bringing premium, minimalist electronics closer to you. Quality and customer satisfaction are at the heart of everything we do.'
  });

  useEffect(() => {
    const loadFounderData = () => {
      try {
        const data = localStorage.getItem('mk_founder');
        if (data) {
          setFounderData(JSON.parse(data));
        }
      } catch (e) {}
    };
    loadFounderData();
    window.addEventListener('founder-updated', loadFounderData);
    return () => window.removeEventListener('founder-updated', loadFounderData);
  }, []);

  return (
    <section id="about-founder" className="py-24 bg-luxury-zinc text-white relative">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="absolute -inset-4 bg-white/5 rounded-3xl transform rotate-3" />
            <div className="relative aspect-[4/5] rounded-2xl overflow-hidden bg-black">
              <img 
                src={founderData.image} 
                alt={founderData.name} 
                className="w-full h-full object-cover filter contrast-125 saturate-50"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-8">
                <h3 className="text-3xl font-display font-bold text-white">{founderData.name}</h3>
                <p className="text-gray-300 font-medium">{founderData.title}</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex flex-col justify-center"
          >
            <Quote className="w-12 h-12 text-white/20 mb-8" />
            <h2 className="text-3xl md:text-5xl font-display font-medium leading-tight mb-8">
              "A commitment to excellence in every piece we deliver."
            </h2>
            <p className="text-xl text-gray-400 font-light leading-relaxed mb-8">
              {founderData.quote}
            </p>
            <div className="flex items-center gap-4">
               <div className="w-12 h-[1px] bg-white/30 truncate" />
               <span className="text-sm tracking-widest uppercase font-medium text-white/50">The Visionary</span>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
