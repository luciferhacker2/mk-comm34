import { motion } from 'motion/react';
import { Truck, ShieldCheck, CreditCard, RefreshCcw, Headset } from 'lucide-react';

const features = [
  { icon: Truck, title: 'Fast Delivery', desc: 'Complimentary expedited shipping' },
  { icon: ShieldCheck, title: 'Original Products', desc: '100% authentic brand guarantees' },
  { icon: CreditCard, title: 'Secure Payments', desc: 'Encrypted checkout process' },
  { icon: RefreshCcw, title: 'Easy Returns', desc: 'Hassle-free 30-day returns' },
  { icon: Headset, title: '24/7 Support', desc: 'Always here to assist you' },
];

export default function Features() {
  return (
    <section className="py-20 bg-luxury-black border-y border-white/5">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-4">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="flex flex-col items-center justify-center text-center p-4 rounded-2xl hover:bg-white/5 transition-colors duration-300"
              >
                <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center mb-4">
                  <Icon className="w-6 h-6 text-gray-200" />
                </div>
                <h4 className="text-sm font-semibold mb-1 text-white">{feature.title}</h4>
                <p className="text-xs text-gray-400 leading-relaxed font-light">{feature.desc}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
