export const CATEGORIES = [
  { id: 1, name: "Mobile Accessories", image: "https://images.unsplash.com/photo-1583394838336-acd977736f90?w=600&q=80" },
  { id: 2, name: "Premium Earbuds", image: "https://images.unsplash.com/photo-1601522582258-fbfc92b67f4c?w=600&q=80" },
  { id: 3, name: "Smart Watches", image: "https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=600&q=80" },
  { id: 4, name: "Chargers & Cables", image: "https://images.unsplash.com/photo-1585338107529-13afc5f02586?w=600&q=80" },
  { id: 5, name: "Gaming Gear", image: "https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=600&q=80" },
  { id: 6, name: "Phone Covers", image: "https://images.unsplash.com/photo-1622445275463-afa2ab738c34?w=600&q=80" }
];

export const TRENDING_PRODUCTS = [
  {
    id: 1,
    name: "Aura Pro Wireless Earbuds",
    price: 2999,
    originalPrice: 4999,
    image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&q=80",
    badge: "Bestseller",
    badgeColor: "bg-luxury-gold"
  },
  {
    id: 2,
    name: "Titan X Smartwatch",
    price: 5499,
    originalPrice: 7999,
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&q=80",
    badge: "New Arrival",
    badgeColor: "bg-white text-black"
  },
  {
    id: 3,
    name: "MagCharge Elite Pad",
    price: 1999,
    originalPrice: null,
    image: "https://images.unsplash.com/photo-1610945265064-32010839e14a?w=800&q=80",
    badge: null,
    badgeColor: null
  },
  {
    id: 4,
    name: "Carbon Fiber MagCase",
    price: 999,
    originalPrice: 1499,
    image: "https://images.unsplash.com/photo-1605646197148-522616f733f1?w=800&q=80",
    badge: "Trending",
    badgeColor: "bg-luxury-gold"
  }
];

export const TESTIMONIALS = [
  {
    id: 1,
    name: "Alex Sterling",
    role: "Tech Reviewer",
    content: "The quality of MK Communication's accessories is unmatched. Their earbuds have incredible soundstage and the build feels distinctly premium.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80",
    rating: 5
  },
  {
    id: 2,
    name: "Samantha Reed",
    role: "Verified Buyer",
    content: "Absolutely love the minimalist design of their wireless chargers. It looks like a piece of art on my desk. Fast shipping too!",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80",
    rating: 5
  },
  {
    id: 3,
    name: "David Chen",
    role: "Verified Buyer",
    content: "Finally, a store that gets both aesthetics and functionality right. The Titan X smartwatch has become my daily driver.",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80",
    rating: 4
  }
];

export const SOCIAL_GALLERY = [
  "https://images.unsplash.com/photo-1600607686527-6fb886090705?w=500&q=80",
  "https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=500&q=80",
  "https://images.unsplash.com/photo-1583394838336-acd977736f90?w=500&q=80",
  "https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=500&q=80",
  "https://images.unsplash.com/photo-1526694852028-1b089c9e847c?w=500&q=80"
];
